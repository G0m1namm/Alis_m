StateSwitcher = function(game) {


};


StateSwitcher.prototype.switchState = function(fromState, toState) {

        

};
var ss = new StateSwitcher();
