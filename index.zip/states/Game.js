BasicGame.Game = function(game) {


};

BasicGame.Game.prototype = {

    create: function(game) {
      s.createScene(game);

    },

    update: function(game) {

      s.updateScene(game);

    },

    render: function(game) {


    },
    shutdown: function() {

    },


};
